<?php 
    $config = Array(
      'protocol' => 'smtp',
      'smtp_host' => 'smtp.mailtrap.io',
      'smtp_port' => 2525,
      'smtp_user' => '3a5d3fade6a6aa',
      'smtp_pass' => 'c0d3ac3a5e4a48',
      'crlf' => "\r\n",
      'newline' => "\r\n"
    );
?>