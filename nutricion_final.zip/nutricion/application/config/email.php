<?php 
    $config = Array(
      'protocol' => 'SMTP',
      'smtp_host' => 'mail.mard.cl',
      'smtp_port' => 465,
      'smtp_user' => '_mainaccount@mard.cl',
      'smtp_pass' => 'mrd1713u',
      'crlf' => "\r\n",
      'newline' => "\r\n",
      'mailtype' => "html"
    );
?>